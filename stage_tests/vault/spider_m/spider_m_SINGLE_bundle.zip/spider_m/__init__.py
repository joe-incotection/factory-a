"""
spider_m — SpiderCAM Tension Scoring Engine
Computes cable tension score and trade tier for SpiderCAM system.
"""
from .engine import run

__all__ = ["run"]
