"""
spider_m/engine.py
SpiderCAM Tension Scoring Engine — Spider-M2 Physical Model

Cable Tension Components:
  x0 = Cable Convergence   — how aligned are the 3 z-scores
  x1 = Spring Load Depth   — how long has the spring been compressed
  x2 = Price Compression   — short ATR vs long ATR (market coiling)
  x3 = Cable Coherence     — how tightly the 3 implied prices cluster

Tension = 0.35*x0 + 0.25*x1 + 0.20*x2 + 0.20*x3

Tiers:
  SKIP  : tension <= tension_skip  → do not trade
  FLAT  : tension <= tension_boost → trade at base lot
  BOOST : tension >  tension_boost → trade at scaled lot (cap: lot_cap_boost)
"""
import numpy as np
from typing import List, Dict, Any


# ── Constants ──────────────────────────────────────────────────────────────
DEFAULT_CONFIG = {
    "z_thresh":       2.5,
    "tension_skip":   0.35,
    "tension_boost":  0.50,
    "load_max_bars":  8,
    "atr_short":      5,
    "atr_long":       32,
    "lot_cap":        0.10,
    "lot_cap_boost":  0.15,
    "boost_slope":    0.5,    # scalar = 1.0 + (tension - boost_t) * slope
}

TIER_SKIP  = "SKIP"
TIER_FLAT  = "FLAT"
TIER_BOOST = "BOOST"


# ── Validation ─────────────────────────────────────────────────────────────
def _validate(payload: Dict[str, Any], config: Dict[str, Any]) -> None:
    required_payload = ["z_scores", "persist_count", "high_arr", "low_arr",
                        "imp_prices", "bar_index"]
    for key in required_payload:
        if key not in payload:
            raise ValueError(f"spider_m: missing payload key '{key}'")

    if len(payload["z_scores"]) != 3:
        raise ValueError("spider_m: z_scores must have exactly 3 values")
    if len(payload["imp_prices"]) != 3:
        raise ValueError("spider_m: imp_prices must have exactly 3 values")
    if len(payload["high_arr"]) != len(payload["low_arr"]):
        raise ValueError("spider_m: high_arr and low_arr must be same length")

    skip_t  = config.get("tension_skip",  DEFAULT_CONFIG["tension_skip"])
    boost_t = config.get("tension_boost", DEFAULT_CONFIG["tension_boost"])
    if boost_t <= skip_t:
        raise ValueError(f"spider_m: tension_boost ({boost_t}) must be > tension_skip ({skip_t})")


# ── Core Computation ───────────────────────────────────────────────────────
def _compute_tension(z_scores: List[float],
                     persist_count: int,
                     high_arr: np.ndarray,
                     low_arr:  np.ndarray,
                     imp_prices: List[float],
                     bar_index: int,
                     config: Dict[str, Any]) -> Dict[str, float]:
    """Compute 4 tension components and return weighted score."""
    z_thresh      = config.get("z_thresh",      DEFAULT_CONFIG["z_thresh"])
    load_max_bars = config.get("load_max_bars",  DEFAULT_CONFIG["load_max_bars"])
    atr_short     = config.get("atr_short",      DEFAULT_CONFIG["atr_short"])
    atr_long      = config.get("atr_long",       DEFAULT_CONFIG["atr_long"])

    # x0: Cable Convergence — tighter z cluster = stronger signal
    x0 = max(0.0, 1.0 - float(np.std(z_scores)) / z_thresh)

    # x1: Spring Load Depth — longer persist = deeper compression
    x1 = min(1.0, persist_count / float(load_max_bars))

    # x2: Price Compression — short ATR < long ATR = coiling
    if bar_index >= atr_long:
        atr_s = float(np.mean(high_arr[bar_index-atr_short+1:bar_index+1]
                             - low_arr[bar_index-atr_short+1:bar_index+1]))
        atr_l = float(np.mean(high_arr[bar_index-atr_long+1:bar_index+1]
                             - low_arr[bar_index-atr_long+1:bar_index+1]))
        ratio   = atr_s / atr_l if atr_l > 1e-12 else 1.0
        x2      = max(0.0, 1.0 - ratio)
        atr_ref = atr_l
    else:
        x2      = 0.5
        atr_ref = float(high_arr[bar_index] - low_arr[bar_index]) + 1e-12

    # x3: Cable Coherence — tight implied price cluster = clean signal
    x3 = max(0.0, min(1.0, 1.0 - float(np.std(imp_prices)) / atr_ref))

    tension = 0.35*x0 + 0.25*x1 + 0.20*x2 + 0.20*x3

    return {
        "x0_convergence": round(x0, 6),
        "x1_load_depth":  round(x1, 6),
        "x2_compression": round(x2, 6),
        "x3_coherence":   round(x3, 6),
        "tension":        round(tension, 6),
        "atr_ref":        round(atr_ref, 8),
    }


def _compute_tier(tension: float, config: Dict[str, Any]) -> Dict[str, Any]:
    """Determine trade tier and lot scalar from tension score."""
    skip_t      = config.get("tension_skip",  DEFAULT_CONFIG["tension_skip"])
    boost_t     = config.get("tension_boost", DEFAULT_CONFIG["tension_boost"])
    boost_slope = config.get("boost_slope",   DEFAULT_CONFIG["boost_slope"])
    lot_cap     = config.get("lot_cap",       DEFAULT_CONFIG["lot_cap"])
    lot_cap_bst = config.get("lot_cap_boost", DEFAULT_CONFIG["lot_cap_boost"])

    if tension <= skip_t:
        tier   = TIER_SKIP
        scalar = 1.0
        cap    = lot_cap
    elif tension <= boost_t:
        tier   = TIER_FLAT
        scalar = 1.0
        cap    = lot_cap
    else:
        tier   = TIER_BOOST
        scalar = 1.0 + (tension - boost_t) * boost_slope
        cap    = lot_cap_bst

    return {
        "tier":           tier,
        "lot_scalar":     round(scalar, 4),
        "lot_cap_active": cap,
        "tradeable":      tier != TIER_SKIP,
    }


# ── Public API ─────────────────────────────────────────────────────────────
def run(payload: Dict[str, Any], config: Dict[str, Any] = None) -> Dict[str, Any]:
    """
    Compute SpiderCAM tension score and trade tier.

    payload:
        z_scores      : list[float]  — 3 cable z-scores
        persist_count : int          — bars signal has persisted
        high_arr      : list[float]  — bar high prices (full history up to bar_index)
        low_arr       : list[float]  — bar low prices
        imp_prices    : list[float]  — 3 implied prices at current bar
        bar_index     : int          — current bar index in high_arr/low_arr

    config (optional, uses defaults if omitted):
        z_thresh, tension_skip, tension_boost, load_max_bars,
        atr_short, atr_long, lot_cap, lot_cap_boost, boost_slope

    returns:
        tension, x0-x3, tier, lot_scalar, lot_cap_active, tradeable
    """
    if config is None:
        config = {}

    _validate(payload, config)

    high_arr = np.array(payload["high_arr"], dtype=float)
    low_arr  = np.array(payload["low_arr"],  dtype=float)

    components = _compute_tension(
        z_scores      = payload["z_scores"],
        persist_count = int(payload["persist_count"]),
        high_arr      = high_arr,
        low_arr       = low_arr,
        imp_prices    = payload["imp_prices"],
        bar_index     = int(payload["bar_index"]),
        config        = config,
    )

    tier_result = _compute_tier(components["tension"], config)

    return {**components, **tier_result}
