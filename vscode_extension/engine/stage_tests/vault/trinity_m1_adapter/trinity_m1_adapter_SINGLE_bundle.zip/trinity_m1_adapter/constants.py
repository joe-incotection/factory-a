"""Constants for TRINITY_M1_ADAPTER.

All values are locked per GOLDEN_IO_LOCK_TRINITY_M1_ADAPTER.yaml and
TRINITY_M1_ADAPTER_REASON_CODES.yaml. Do not modify without S1 approval.
"""

from __future__ import annotations

# ---------------------------------------------------------------------------
# Identity locks (INV_ADAPTER_VERSION_LOCK, INV_SOURCE_MODULE_LOCK)
# ---------------------------------------------------------------------------

ADAPTER_VERSION: str = "v1.0"
SOURCE_MODULE: str = "trinity_m1"

# ---------------------------------------------------------------------------
# Mapping status values
# ---------------------------------------------------------------------------

MAPPING_STATUS_OK: str = "OK"
MAPPING_STATUS_PARTIAL: str = "PARTIAL"
MAPPING_STATUS_BLOCKED: str = "BLOCKED"

# ---------------------------------------------------------------------------
# Input contract — required top-level fields (GOLDEN_IO_LOCK input_contract)
# ---------------------------------------------------------------------------

REQUIRED_INPUT_FIELDS: tuple[str, ...] = (
    "cleaned_structure_signal",
    "noise_residual",
    "spectral_signature",
    "broker_audit",
    "metadata",
)

# ---------------------------------------------------------------------------
# Candidate feature keys — optional; null if absent (PARTIAL path)
# ---------------------------------------------------------------------------

CANDIDATE_FEATURE_KEYS: tuple[str, ...] = (
    "fx_correlation",
    "oil_price",
    "yield_10y",
)
# Note: missing_fields are sorted lexically by sort_missing_fields() in utils.py
# (INV_MISSING_FIELDS_ORDER). The key order here does not affect output ordering.

# ---------------------------------------------------------------------------
# Reason codes allowlist (TRINITY_M1_ADAPTER_REASON_CODES.yaml)
# ---------------------------------------------------------------------------

REASON_CODES_ALLOWLIST: frozenset[str] = frozenset({
    "TRINITY_M1_ADAPTER_INPUT_SCHEMA_INVALID",
    "TRINITY_M1_ADAPTER_INPUT_MISSING_FIELD",
    "TRINITY_M1_ADAPTER_INPUT_TYPE_MISMATCH",
    "TRINITY_M1_ADAPTER_REQUIRED_FIELD_MISSING",
    "TRINITY_M1_ADAPTER_OPTIONAL_FIELD_MISSING",
    "TRINITY_M1_ADAPTER_INVALID_INPUT_SHAPE",
    "TRINITY_M1_ADAPTER_EVIDENCE_REF_INVALID",
    "TRINITY_M1_ADAPTER_REASON_CODE_INVALID",
    "TRINITY_M1_ADAPTER_INTERNAL_ERROR",
})
