"""TRINITY_M1_ADAPTER — boundary-layer adapter for TRINITY_M1 certified output.

Converts certified TRINITY_M1 output into a deterministic adapter payload
for downstream Phase 2 modules (FeatureNormalizer, EvidenceBundleBuilder).

Public API:
    from trinity_m1_adapter.engine import run_trinity_m1_adapter
    from trinity_m1_adapter.exceptions import TrinityM1AdapterError
"""

from trinity_m1_adapter.engine import run_trinity_m1_adapter
from trinity_m1_adapter.exceptions import TrinityM1AdapterError

__all__ = ["run_trinity_m1_adapter", "TrinityM1AdapterError"]
