"""Typed exceptions for TRINITY_M1_ADAPTER.

All hard-fail conditions raise TrinityM1AdapterError with allowlisted
reason codes from TRINITY_M1_ADAPTER_REASON_CODES.yaml.
"""

from __future__ import annotations


class TrinityM1AdapterError(Exception):
    """Hard-fail exception for TRINITY_M1_ADAPTER boundary violations.

    Raised on any condition listed under failure_behavior.hard_fail in
    GOLDEN_IO_LOCK_TRINITY_M1_ADAPTER.yaml. No partial-success-on-error
    path is permitted.

    Attributes:
        message: Human-readable description of the failure.
        reason_codes: Non-empty list of allowlisted reason codes
            from TRINITY_M1_ADAPTER_REASON_CODES.yaml.
    """

    def __init__(self, message: str, reason_codes: list[str]) -> None:
        super().__init__(message)
        self.message: str = message
        self.reason_codes: list[str] = reason_codes
