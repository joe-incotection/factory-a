"""TRINITY_M1_ADAPTER engine — single public entry point.

Implements run_trinity_m1_adapter() per SMART_SPEC_TRINITY_M1_ADAPTER.md
Section 2. All mapping rules are enforced; no scoring, routing, or
market-semantic invention is permitted.
"""

from __future__ import annotations

from trinity_m1_adapter.constants import (
    ADAPTER_VERSION,
    MAPPING_STATUS_OK,
    MAPPING_STATUS_PARTIAL,
    REASON_CODES_ALLOWLIST,
    REQUIRED_INPUT_FIELDS,
    SOURCE_MODULE,
)
from trinity_m1_adapter.exceptions import TrinityM1AdapterError
from trinity_m1_adapter.mapper import (
    map_candidate_features,
    map_detected_patterns,
    map_evidence_refs,
    map_noise_residual_array,
    map_trinity_signal,
    map_trust_score,
)


def _validate_reason_codes(codes: list[str]) -> None:
    """Assert every code is in the allowlist (INV allowlist discipline).

    Args:
        codes: Reason codes to validate.

    Raises:
        TrinityM1AdapterError: If any code is not allowlisted.
    """
    for code in codes:
        if code not in REASON_CODES_ALLOWLIST:
            raise TrinityM1AdapterError(
                f"Reason code not in allowlist: {code!r}",
                reason_codes=["TRINITY_M1_ADAPTER_REASON_CODE_INVALID"],
            )


def run_trinity_m1_adapter(input_payload: dict) -> dict:
    """Convert certified TRINITY_M1 output into an adapter payload.

    Mapping-only: selects, copies, renames, reorders, and preserves nulls.
    No scoring, routing, veto, or market-semantic invention.

    Args:
        input_payload: Certified TRINITY_M1 success output dict.

    Returns:
        Adapter output payload conforming to
        GOLDEN_IO_LOCK_TRINITY_M1_ADAPTER.yaml output_contract.

    Raises:
        TrinityM1AdapterError: On any hard-fail condition:
            - input is not a dict (INVALID_INPUT_SHAPE)
            - required input field missing (REQUIRED_FIELD_MISSING)
            - required mapped field cannot be derived (REQUIRED_FIELD_MISSING)
            - evidence_log item malformed (EVIDENCE_REF_INVALID)
            - reason code not in allowlist (REASON_CODE_INVALID)
    """
    # ------------------------------------------------------------------
    # INV_INPUT_REQUIRED_KEYS_PRESENT — shape + presence checks
    # ------------------------------------------------------------------
    if not isinstance(input_payload, dict):
        raise TrinityM1AdapterError(
            "Input payload must be a dict",
            reason_codes=["TRINITY_M1_ADAPTER_INVALID_INPUT_SHAPE"],
        )

    for field in REQUIRED_INPUT_FIELDS:
        if field not in input_payload:
            raise TrinityM1AdapterError(
                f"Required input field missing: {field!r}",
                reason_codes=["TRINITY_M1_ADAPTER_REQUIRED_FIELD_MISSING"],
            )

    # ------------------------------------------------------------------
    # Map evidence_refs (may raise EVIDENCE_REF_INVALID)
    # ------------------------------------------------------------------
    evidence_refs = map_evidence_refs(input_payload)

    # ------------------------------------------------------------------
    # Map candidate features (optional — PARTIAL path)
    # ------------------------------------------------------------------
    candidate_features, missing_fields, feature_codes = map_candidate_features(
        input_payload
    )

    # ------------------------------------------------------------------
    # Map trinity_signal — required for mapped_context
    # ------------------------------------------------------------------
    trinity_signal = map_trinity_signal(input_payload)
    if trinity_signal is None:
        raise TrinityM1AdapterError(
            "Required mapped field missing: trinity_signal "
            "(neither cleaned_structure_signal.signal_label "
            "nor metadata.trinity_signal is present)",
            reason_codes=["TRINITY_M1_ADAPTER_REQUIRED_FIELD_MISSING"],
        )

    # ------------------------------------------------------------------
    # Determine mapping_status
    # ------------------------------------------------------------------
    mapping_status = MAPPING_STATUS_PARTIAL if missing_fields else MAPPING_STATUS_OK

    # ------------------------------------------------------------------
    # Assemble reason_codes (allowlist-validated)
    # ------------------------------------------------------------------
    reason_codes: list[str] = list(feature_codes)
    _validate_reason_codes(reason_codes)

    # ------------------------------------------------------------------
    # Assemble mapped_context (copy-only per mapping table)
    # ------------------------------------------------------------------
    mapped_context: dict = {
        "trinity_signal": trinity_signal,
        "noise_residual": input_payload["noise_residual"],
        "broker_audit": input_payload["broker_audit"],
    }

    # ------------------------------------------------------------------
    # Map remaining top-level output fields
    # ------------------------------------------------------------------
    noise_residual_array = map_noise_residual_array(input_payload)
    trust_score = map_trust_score(input_payload)
    detected_patterns = map_detected_patterns(input_payload)

    # ------------------------------------------------------------------
    # Build and return output (INV_OUTPUT_REQUIRED_KEYS)
    # ------------------------------------------------------------------
    output: dict = {
        "adapter_version": ADAPTER_VERSION,
        "source_module": SOURCE_MODULE,
        "mapping_status": mapping_status,
        "noise_residual": noise_residual_array,
        "trust_score": trust_score,
        "detected_patterns": detected_patterns,
        "mapped_context": mapped_context,
        "candidate_features": candidate_features,
        "evidence_refs": evidence_refs,
        "missing_fields": missing_fields,
        "reason_codes": reason_codes,
    }

    return output
