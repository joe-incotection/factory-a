"""Typed models for TRINITY_M1_ADAPTER.

Defines TypedDict shapes matching GOLDEN_IO_LOCK_TRINITY_M1_ADAPTER.yaml
for static analysis and documentation purposes.
"""

from __future__ import annotations

from typing import List, Optional
from typing import TypedDict


class EvidenceRef(TypedDict):
    """Single evidence reference extracted from broker_audit.evidence_log."""

    eid: str
    source: str
    data_hash: str


class MappedContext(TypedDict):
    """Core trinity context passed to downstream Phase 2 modules."""

    trinity_signal: str
    noise_residual: dict
    broker_audit: dict


class CandidateFeatures(TypedDict):
    """Optional candidate feature values; null when not present in input."""

    oil_price: Optional[float]
    yield_10y: Optional[float]
    fx_correlation: Optional[float]


class AdapterOutput(TypedDict):
    """Full adapter output per GOLDEN_IO_LOCK_TRINITY_M1_ADAPTER.yaml output_contract."""

    adapter_version: str
    source_module: str
    mapping_status: str
    noise_residual: List
    trust_score: float
    detected_patterns: List[str]
    mapped_context: MappedContext
    candidate_features: CandidateFeatures
    evidence_refs: List[EvidenceRef]
    missing_fields: List[str]
    reason_codes: List[str]
