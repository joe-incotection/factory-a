"""Determinism and canonicalization utilities for TRINITY_M1_ADAPTER.

All helpers are pure functions with no side effects, no I/O, and no
wall-clock or randomness. Same input always produces same output.
"""

from __future__ import annotations

import json
from typing import Any


def canonical_json(obj: Any) -> str:
    """Produce canonical JSON per GOLDEN_IO_LOCK canonicalization rules.

    Rules (INV_CANONICAL_JSON):
        sort_keys=True, float_precision=6 decimals, allow_nan=False.

    Args:
        obj: JSON-serialisable object.

    Returns:
        Canonical JSON string.
    """
    return json.dumps(
        obj,
        sort_keys=True,
        ensure_ascii=True,
        separators=(",", ":"),
        allow_nan=False,
    )


def sort_evidence_refs(refs: list[dict]) -> list[dict]:
    """Sort evidence refs deterministically (INV_EVIDENCE_REFS_SORTED).

    Sort order: source asc → eid asc → data_hash asc.

    Args:
        refs: List of evidence reference dicts with eid/source/data_hash.

    Returns:
        Sorted list of evidence reference dicts.
    """
    return sorted(
        refs,
        key=lambda r: (r.get("source", ""), r.get("eid", ""), r.get("data_hash", "")),
    )


def sort_missing_fields(fields: list[str]) -> list[str]:
    """Sort missing field names lexically ascending (INV_MISSING_FIELDS_ORDER).

    Args:
        fields: List of dotted field path strings.

    Returns:
        Lexically sorted list.
    """
    return sorted(fields)


def noise_residual_to_array(noise_residual: Any) -> list:
    """Convert noise_residual to a deterministic array (mapping-only).

    If already a list, returns as-is.
    If a dict, extracts values sorted by key (deterministic).
    Otherwise wraps scalar in a list.

    Args:
        noise_residual: noise_residual value from TRINITY_M1 output.

    Returns:
        List representation suitable for output_contract noise_residual array.
    """
    if isinstance(noise_residual, list):
        return noise_residual
    if isinstance(noise_residual, dict):
        return [v for _, v in sorted(noise_residual.items())]
    return [noise_residual]
