"""Pure mapping helpers for TRINITY_M1_ADAPTER.

Each function is mapping-only: select, copy, rename, reorder, or preserve
nulls. No scoring, routing, veto, or market-semantic invention is permitted.
"""

from __future__ import annotations

from typing import Optional

from trinity_m1_adapter.constants import CANDIDATE_FEATURE_KEYS
from trinity_m1_adapter.exceptions import TrinityM1AdapterError
from trinity_m1_adapter.utils import (
    noise_residual_to_array,
    sort_evidence_refs,
    sort_missing_fields,
)


def map_trinity_signal(payload: dict) -> Optional[str]:
    """Map trinity_signal per SMART_SPEC mapping table.

    Rule: cleaned_structure_signal.signal_label if present,
          else metadata.trinity_signal if present,
          else None.

    Args:
        payload: Validated TRINITY_M1 input dict.

    Returns:
        trinity_signal string or None if neither source is available.
    """
    css = payload.get("cleaned_structure_signal", {})
    if isinstance(css, dict) and "signal_label" in css:
        return str(css["signal_label"])
    meta = payload.get("metadata", {})
    if isinstance(meta, dict) and "trinity_signal" in meta:
        return str(meta["trinity_signal"])
    return None


def map_candidate_features(
    payload: dict,
) -> tuple[dict[str, Optional[float]], list[str], list[str]]:
    """Map optional candidate features from metadata.context.

    Missing features → null, add to missing_fields (lexical order),
    emit TRINITY_M1_ADAPTER_OPTIONAL_FIELD_MISSING if any absent.

    Args:
        payload: Validated TRINITY_M1 input dict.

    Returns:
        Tuple of (features_dict, sorted_missing_fields, reason_codes).
    """
    meta = payload.get("metadata", {})
    ctx = meta.get("context", {}) if isinstance(meta, dict) else {}

    features: dict[str, Optional[float]] = {}
    missing: list[str] = []
    codes: list[str] = []

    for key in CANDIDATE_FEATURE_KEYS:
        if isinstance(ctx, dict) and key in ctx:
            features[key] = ctx[key]
        else:
            features[key] = None
            missing.append(f"candidate_features.{key}")

    if missing and "TRINITY_M1_ADAPTER_OPTIONAL_FIELD_MISSING" not in codes:
        codes.append("TRINITY_M1_ADAPTER_OPTIONAL_FIELD_MISSING")

    return features, sort_missing_fields(missing), codes


def map_evidence_refs(payload: dict) -> list[dict]:
    """Extract and sort evidence refs from broker_audit.evidence_log.

    Selects only {eid, source, data_hash} per GOLDEN_IO_LOCK evidence_refs
    contract. Sorted by source asc → eid asc → data_hash asc
    (INV_EVIDENCE_REFS_SORTED).

    Args:
        payload: Validated TRINITY_M1 input dict.

    Returns:
        Deterministically sorted list of evidence reference dicts.

    Raises:
        TrinityM1AdapterError: If any evidence_log item is malformed.
    """
    broker_audit = payload.get("broker_audit", {})
    evidence_log = (
        broker_audit.get("evidence_log", []) if isinstance(broker_audit, dict) else []
    )

    refs: list[dict] = []
    for item in evidence_log:
        if not isinstance(item, dict):
            raise TrinityM1AdapterError(
                "evidence_log item is not a dict",
                reason_codes=["TRINITY_M1_ADAPTER_EVIDENCE_REF_INVALID"],
            )
        missing_keys = [k for k in ("eid", "source", "data_hash") if k not in item]
        if missing_keys:
            raise TrinityM1AdapterError(
                f"evidence_log item missing required keys: {missing_keys}",
                reason_codes=["TRINITY_M1_ADAPTER_EVIDENCE_REF_INVALID"],
            )
        refs.append(
            {
                "eid": str(item["eid"]),
                "source": str(item["source"]),
                "data_hash": str(item["data_hash"]),
            }
        )

    return sort_evidence_refs(refs)


def map_detected_patterns(payload: dict) -> list[str]:
    """Extract unique detected pattern names from broker_audit.evidence_log.

    Collects all pattern_name values, deduplicates, sorts lexically.

    Args:
        payload: Validated TRINITY_M1 input dict.

    Returns:
        Sorted list of unique pattern name strings.
    """
    broker_audit = payload.get("broker_audit", {})
    evidence_log = (
        broker_audit.get("evidence_log", []) if isinstance(broker_audit, dict) else []
    )
    patterns = sorted(
        {
            str(item["pattern_name"])
            for item in evidence_log
            if isinstance(item, dict) and "pattern_name" in item
        }
    )
    return patterns


def map_trust_score(payload: dict) -> float:
    """Extract trust_score from broker_audit.

    Args:
        payload: Validated TRINITY_M1 input dict.

    Returns:
        trust_score as float.
    """
    broker_audit = payload.get("broker_audit", {})
    if isinstance(broker_audit, dict):
        return float(broker_audit.get("trust_score", 0.0))
    return 0.0


def map_noise_residual_array(payload: dict) -> list:
    """Extract noise_residual as a deterministic array.

    Args:
        payload: Validated TRINITY_M1 input dict.

    Returns:
        List representation of noise_residual.
    """
    return noise_residual_to_array(payload.get("noise_residual", {}))
