"""
Stage 2: Pattern Detection and Signal Generation
"""
from .constants import SIGNAL_BUY, SIGNAL_SELL, SIGNAL_NONE

def detect_signal(cleaned_close: list[float], vol: float):
    if len(cleaned_close) < 2:
        return SIGNAL_NONE, 0.0

    last_price = cleaned_close[-1]
    prev_price = cleaned_close[-2]
    
    # Basic Trend Pattern
    if last_price > prev_price:
        signal = SIGNAL_BUY
    elif last_price < prev_price:
        signal = SIGNAL_SELL
    else:
        signal = SIGNAL_NONE
        
    # Confidence based on volatility inverse (lower vol = higher confidence in pattern)
    confidence = max(0.0, min(1.0, 1.0 - (vol * 10)))
    
    return signal, confidence