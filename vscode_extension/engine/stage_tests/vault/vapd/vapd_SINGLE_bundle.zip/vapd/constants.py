"""
Module constants and thresholds.
"""
VERSION = "1.0"
MODULE_NAME = "VAPD"

# Signal Enums
SIGNAL_BUY = "BUY"
SIGNAL_SELL = "SELL"
SIGNAL_NONE = "NONE"

# Regime Enums
REGIME_LOW = "LOW"
REGIME_NORMAL = "NORMAL"
REGIME_HIGH = "HIGH"
REGIME_EXTREME = "EXTREME"

# Thresholds (Default if not in config)
MIN_DATA_POINTS = 5
VOL_WINDOW = 14
Z_SCORE_THRESHOLD = 2.0