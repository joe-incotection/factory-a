"""
Stage 3: Survival Law S3 - Drift & Regime Flip Detection
"""
import statistics
from .reason_codes import VAPD_VOLATILITY_SPIKE, VAPD_REGIME_FLIP, VAPD_ANOMALY_DETECTED


def check_drift(cleaned_close: list[float], current_vol: float, current_regime: str, config: dict):
    reasons = []

    # 1. Volatility Spike Detection — baseline จาก cleaned_close จริง
    if len(cleaned_close) > 5:
        returns = [
            abs((cleaned_close[i] / cleaned_close[i - 1]) - 1)
            for i in range(1, len(cleaned_close))
            if cleaned_close[i - 1] != 0
        ]
        if returns:
            baseline_vol = statistics.mean(returns) if len(returns) < 2 else statistics.stdev(returns)
            baseline_vol = max(baseline_vol, 1e-8)  # กันหาร 0
            if current_vol > baseline_vol * 2:
                reasons.append(VAPD_VOLATILITY_SPIKE)

    # 2. Regime Flip
    if current_regime in ["HIGH", "EXTREME"]:
        reasons.append(VAPD_REGIME_FLIP)

    # 3. Anomaly Detection (Price Jump > 10%)
    if len(cleaned_close) >= 2:
        price_jump = abs((cleaned_close[-1] / cleaned_close[-2]) - 1)
        if price_jump > 0.10:
            reasons.append(VAPD_ANOMALY_DETECTED)

    return reasons