"""
Stage 4: Assembly Engine
Final coordination of VAPD logic.
"""
from datetime import datetime, timezone
from typing import List, Dict, Any
from . import volatility, pattern, drift_detector, reason_codes, constants, models

def run(cleaned_close: List[float], config: Dict[str, Any]) -> Dict[str, Any]:
    # Hard Rule: Min length check
    if not cleaned_close or len(cleaned_close) < constants.MIN_DATA_POINTS:
         raise ValueError(f"cleaned_close length must be >= {constants.MIN_DATA_POINTS}, got {len(cleaned_close) if cleaned_close else 0}")

    # Config retrieval
    vol_win = config.get("volatility_window", constants.VOL_WINDOW)
    threshold = config.get("threshold", 0.5)

    # Execution Pipeline
    vol, regime = volatility.calculate_metrics(cleaned_close, vol_win)
    sig_type, conf = pattern.detect_signal(cleaned_close, vol)
    
    # Survival Law S3
    drift_reasons = drift_detector.check_drift(cleaned_close, vol, regime, config)
    
    # Logic Merging
    final_reasons = list(set(drift_reasons))
    
    # Anomaly blocking
    if reason_codes.VAPD_ANOMALY_DETECTED in final_reasons:
        sig_type = constants.SIGNAL_NONE
        conf = 0.0
    
    # Confidence filtering
    if conf < threshold and sig_type != constants.SIGNAL_NONE:
        final_reasons.append(reason_codes.VAPD_SIGNAL_WEAK)

    # Output Construction
    output = models.VAPDOutput(
        signal_type=sig_type,
        confidence=conf,
        reason_codes=final_reasons,
        volatility_current=vol,
        volatility_regime=regime,
        timestamp=config.get("force_timestamp", "1970-01-01T00:00:00+00:00")
    )

    return output.to_dict()