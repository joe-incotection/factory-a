"""
Stage 1: Volatility Calculation
"""
import math
from .constants import REGIME_LOW, REGIME_NORMAL, REGIME_HIGH, REGIME_EXTREME

def calculate_metrics(cleaned_close: list[float], window: int):
    if len(cleaned_close) < 2:
        return 0.0, REGIME_NORMAL
    
    # Simple Volatility (Standard Deviation of returns)
    returns = [(cleaned_close[i] / cleaned_close[i-1]) - 1 for i in range(1, len(cleaned_close))]
    mean_ret = sum(returns) / len(returns)
    variance = sum((r - mean_ret)**2 for r in returns) / len(returns)
    vol = math.sqrt(variance)
    
    # Regime Logic (Simplified for deterministic output)
    if vol > 0.05: regime = REGIME_EXTREME
    elif vol > 0.03: regime = REGIME_HIGH
    elif vol > 0.01: regime = REGIME_NORMAL
    else: regime = REGIME_LOW
    
    return vol, regime