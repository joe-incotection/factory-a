"""
VAPD Module v1.0 - Volatility Analysis & Pattern Detection
Entry point for PythonBrain ecosystem.
"""
from .engine import run

__all__ = ["run"]