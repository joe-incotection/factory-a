"""
Data structures for VAPD module. (NOT types.py to avoid conflicts)
"""
from dataclasses import dataclass, field
from typing import List, Dict, Any

@dataclass(frozen=True)
class VAPDOutput:
    signal_type: str  # BUY, SELL, NONE
    confidence: float
    reason_codes: List[str]
    volatility_current: float
    volatility_regime: str
    timestamp: str

    def to_dict(self) -> Dict[str, Any]:
        return {
            "vapd_output": {
                "signal_type": self.signal_type,
                "confidence": float(f"{self.confidence:.6f}"),
                "metadata": {
                    "reason_codes": sorted(self.reason_codes),
                    "timestamp": self.timestamp,
                    "module": "VAPD",
                    "version": "1.0",
                    "volatility_metrics": {
                        "current": float(f"{self.volatility_current:.6f}"),
                        "regime": self.volatility_regime
                    }
                }
            }
        }