from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Dict, Iterator

_KEY_MAP = {"t": "ts_utc", "o": "open", "h": "high", "l": "low", "c": "close", "v": "volume"}

@dataclass(frozen=True, slots=True)
class Bar:
    """Immutable OHLCV bar in UTC."""
    ts_utc: str
    open: float
    high: float
    low: float
    close: float
    volume: float

    def __getitem__(self, key: str) -> Any:
        attr = _KEY_MAP.get(key)
        if attr is None:
            raise KeyError(key)
        return getattr(self, attr)

    def __contains__(self, key: object) -> bool:
        return key in _KEY_MAP

    def get(self, key: str, default: Any = None) -> Any:
        try:
            return self[key]
        except KeyError:
            return default

    def keys(self) -> Iterator[str]:
        return iter(_KEY_MAP.keys())

    @staticmethod
    def from_raw(raw: Dict[str, Any]) -> "Bar":
        ts = str(raw["ts_utc"])
        try:
            if ts.endswith("Z"):
                dt = datetime.fromisoformat(ts.replace("Z", "+00:00"))
            else:
                dt = datetime.fromisoformat(ts)
                if dt.tzinfo is None:
                    dt = dt.replace(tzinfo=timezone.utc)
            ts_norm = dt.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")
        except Exception as e:
            raise ValueError(f"Invalid ts_utc: {ts}") from e

        def f(key: str, default: float | None = None) -> float:
            if key not in raw:
                if default is None:
                    raise KeyError(key)
                return float(default)
            return float(raw[key])

        vol = float(raw.get("volume", 0.0))
        return Bar(
            ts_utc=ts_norm,
            open=f("open"),
            high=f("high"),
            low=f("low"),
            close=f("close"),
            volume=vol,
        )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "t": self.ts_utc,
            "o": self.open,
            "h": self.high,
            "l": self.low,
            "c": self.close,
            "v": self.volume,
        }
