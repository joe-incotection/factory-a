from __future__ import annotations

import hashlib
from typing import Any

from .canonical import canonical_json


def sha256_hex(text: str) -> str:
    h = hashlib.sha256()
    h.update(text.encode("utf-8"))
    return h.hexdigest()


def canonical_digest(obj: Any) -> str:
    """sha256 digest of canonical_json(obj)."""
    return "sha256:" + sha256_hex(canonical_json(obj))
