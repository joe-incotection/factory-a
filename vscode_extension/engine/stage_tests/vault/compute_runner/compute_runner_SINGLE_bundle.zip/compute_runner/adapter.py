from __future__ import annotations

import inspect
import uuid
from typing import Any, Callable, Dict, List, Optional, Tuple

from .bar_types import Bar


class AdapterError(RuntimeError):
    pass


def build_bars(raw_bars: List[Dict[str, Any]]) -> List[Bar]:
    bars: List[Bar] = []
    for raw in raw_bars:
        bars.append(Bar.from_raw(raw))
    return bars


def _resolve_collector_callable() -> Callable[..., Any]:
    try:
        import data_collector  # type: ignore
    except Exception as e:
        raise AdapterError("data_collector import failed") from e
    fn = getattr(data_collector, "collect_window", None)
    if fn is None or not callable(fn):
        raise AdapterError("data_collector.collect_window not found")
    return fn


def call_collect_window(
    symbol: str,
    timeframe: str,
    end_time_utc: str,
    window_bars: int,
    market_bars: List[Bar],
    truth_bars: Optional[List[Bar]] = None,
) -> Tuple[Dict[str, Any], str]:
    fn = _resolve_collector_callable()

    def _to_collector_format(bars: Optional[List[Bar]]) -> Optional[List[Any]]:
        if bars is None:
            return []
        import data_collector as _dc  # type: ignore
        is_stub = not hasattr(_dc, "__file__") or getattr(_dc, "__file__", None) is None
        if is_stub:
            return bars  # stub calls to_dict() itself
        return [b.to_dict() for b in bars]  # real collector needs dict

    try:
        sig = inspect.signature(fn)
        params = list(sig.parameters.values())
        kwargs: Dict[str, Any] = {}

        names = [p.name for p in params]
        if len(params) >= 5 and all(n in names for n in [names[0], names[1]]):
            market_arg = _to_collector_format(market_bars)
            truth_arg = _to_collector_format(truth_bars)
            mapping = {
                "symbol": symbol,
                "timeframe": timeframe,
                "tf": timeframe,
                "end_time_utc": end_time_utc,
                "end_time": end_time_utc,
                "window_bars": window_bars,
                "window_size": window_bars,
                "n_bars": window_bars,
                "market_bars": market_arg,
                "market_window": market_arg,
                "truth_bars": truth_arg,
                "truth_window": truth_arg,
            }
            for p in params:
                if p.kind in (p.VAR_POSITIONAL, p.VAR_KEYWORD):
                    continue
                if p.name in mapping:
                    kwargs[p.name] = mapping[p.name]
            result = fn(**kwargs)  # type: ignore[arg-type]
            return _normalize_collect_result(result), "RC_CR_ADAPTER_SIGNATURE_MAPPED"
        else:
            market_arg = _to_collector_format(market_bars)
            truth_arg = _to_collector_format(truth_bars)
            args = [symbol, timeframe, end_time_utc, window_bars, market_arg]
            if len(params) >= 6:
                args.append(truth_arg)
            result = fn(*args)  # type: ignore[misc]
            return _normalize_collect_result(result), "RC_CR_ADAPTER_SIGNATURE_MAPPED"
    except AdapterError:
        raise
    except Exception as e:
        raise AdapterError("collect_window call failed") from e


def _normalize_collect_result(result: Any) -> Dict[str, Any]:
    if not isinstance(result, dict):
        raise AdapterError("collect_window must return dict")
    if "ok" not in result:
        result = {"ok": True, **result}
    if "market_window" not in result:
        result["market_window"] = []
    if "collector_meta" not in result:
        result["collector_meta"] = {}
    return result


def _resolve_trinity_m1_callable() -> Callable[..., Any]:
    try:
        import trinity_m1  # type: ignore
    except Exception as e:
        raise AdapterError("trinity_m1 import failed") from e

    for name in ("run", "run_trinity_m1", "analyze", "execute"):
        fn = getattr(trinity_m1, name, None)
        if fn is not None and callable(fn):
            return fn
    raise AdapterError("trinity_m1 entry callable not found")


def _convert_window_to_trinity_bars(market_window: Any) -> List[Dict[str, Any]]:
    """Convert collector bars {t,o,h,l,c,v} -> trinity bars {ts_utc,o,h,l,c,v}."""
    if not market_window:
        return []
    result = []
    for b in market_window:
        if isinstance(b, dict):
            bar = dict(b)
            if "t" in bar and "ts_utc" not in bar:
                bar["ts_utc"] = bar.pop("t")
            result.append(bar)
        elif hasattr(b, "to_dict"):
            result.append(b.to_dict())
        else:
            result.append(b)
    return result


def call_trinity_m1(
    symbol: str,
    timeframe: str,
    market_window: Any,
    truth_window: Any = None,
) -> Dict[str, Any]:
    fn = _resolve_trinity_m1_callable()
    try:
        bars = _convert_window_to_trinity_bars(market_window)
        payload = {
            "symbol": symbol,
            "timeframe": timeframe,
            "bars": bars,
            "meta": {
                "source": "compute_runner_adapter",
                "run_id": str(uuid.uuid4()),
            },
        }
        return _normalize_m1(fn(payload))
    except AdapterError:
        raise
    except Exception as e:
        raise AdapterError("trinity_m1 call failed") from e


def _normalize_m1(result: Any) -> Dict[str, Any]:
    if not isinstance(result, dict):
        raise AdapterError("trinity_m1 must return dict")
    
    # Check for required keys - trust_score may be in broker_audit
    if "broker_audit" not in result:
        raise AdapterError("trinity_m1 missing required key: broker_audit")
    if "noise_residual" not in result:
        raise AdapterError("trinity_m1 missing required key: noise_residual")
    
    # Extract trust_score from broker_audit to top level if needed
    if "trust_score" not in result and "trust_score" in result.get("broker_audit", {}):
        result["trust_score"] = result["broker_audit"]["trust_score"]
    
    if "trust_score" not in result:
        raise AdapterError("trinity_m1 missing required key: trust_score")
    
    return result


