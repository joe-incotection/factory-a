from __future__ import annotations

import json
import math
from typing import Any


def _normalize_number(x: Any) -> Any:
    if isinstance(x, float):
        if math.isnan(x) or math.isinf(x):
            return None
        # Fixed rounding to preserve determinism across platforms
        return float(f"{x:.10f}")
    return x


def _canonicalize(obj: Any) -> Any:
    if obj is None:
        return None
    if isinstance(obj, (str, int, bool)):
        return obj
    if isinstance(obj, float):
        return _normalize_number(obj)
    if isinstance(obj, (list, tuple)):
        return [_canonicalize(v) for v in obj]
    if isinstance(obj, dict):
        # Keys must be strings
        items = []
        for k, v in obj.items():
            items.append((str(k), _canonicalize(v)))
        items.sort(key=lambda kv: kv[0])
        return {k: v for k, v in items}
    # dataclass or other objects: try to convert via dict protocol
    if hasattr(obj, "to_dict") and callable(getattr(obj, "to_dict")):
        return _canonicalize(obj.to_dict())
    raise TypeError(f"Unsupported type for canonicalization: {type(obj)!r}")


def canonical_json(obj: Any) -> str:
    """Return canonical JSON string for determinism hashing."""
    canon = _canonicalize(obj)
    return json.dumps(canon, ensure_ascii=False, separators=(",", ":"), sort_keys=True)
