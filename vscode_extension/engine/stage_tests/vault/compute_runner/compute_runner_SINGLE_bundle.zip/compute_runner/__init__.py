"""compute_runner package.

Factory-A CERTIF: adapter-only fixes live here.
"""

from .engine import run_compute

__all__ = ["run_compute"]
