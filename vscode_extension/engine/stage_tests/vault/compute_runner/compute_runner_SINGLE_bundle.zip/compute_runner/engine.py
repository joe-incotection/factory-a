from __future__ import annotations

import json
import math
import os
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from .adapter import AdapterError, build_bars, call_collect_window, call_trinity_m1
from .hashing import canonical_digest

# ---------------------------------------------------------------------------
# Multi-symbol correlation matrix — constants
# ---------------------------------------------------------------------------

_CORR_MATRIX_PATH    = Path(r"C:\Factory-A\artifacts\live_telemetry\correlation_matrix.json")
_EA3_COMPARE_LOG_PATH = Path(r"C:\Factory-A\artifacts\live_telemetry\ea3_compare_log.jsonl")

# Mutable state: router override counter (persists across ticks, reset-able in tests)
_router_state: Dict[str, int] = {"override_count": 0}

_CORR_SYMBOLS: List[str] = [
    # Forex (7)
    "EURUSD", "GBPUSD", "USDJPY", "AUDUSD", "USDCHF", "USDCAD", "NZDUSD",
    # Metals (2)
    "XAUUSD", "XAGUSD",
    # Crypto (2)
    "BTCUSD", "ETHUSD",
    # Indices (2)
    "US30", "US500",
    # Energy (2)
    "USOIL", "UKOIL",
]


# ---------------------------------------------------------------------------
# Multi-symbol correlation helpers (fail-soft, non-blocking)
# ---------------------------------------------------------------------------

_STALE_THRESHOLD_S: float = 30.0   # symbol stale if latest bar > 30s old
_DEGRADED_RATIO:    float = 0.30   # DEGRADED if >30% symbols stale


def _fetch_multi_symbol_bars(
    symbols: List[str],
    n: int = 64,
) -> Dict[str, List[float]]:
    """Fetch M1 close prices for multiple symbols from MT5.

    Fail-soft per symbol: missing / insufficient bars are silently skipped.
    Requires >= 30 bars per symbol to be included.

    Args:
        symbols: List of symbol names (e.g. _CORR_SYMBOLS).
        n:       Number of bars to request from MT5.

    Returns:
        Dict mapping symbol -> list of close prices.
        Returns {} if MT5 is unavailable or no symbols have enough data.
    """
    result: Dict[str, List[float]] = {}
    try:
        import MetaTrader5 as _mt5
        for sym in symbols:
            try:
                rates = _mt5.copy_rates_from_pos(sym, _mt5.TIMEFRAME_M1, 0, n)
                if rates is None or len(rates) < 30:
                    continue
                result[sym] = [float(r["close"]) for r in rates]
            except Exception:
                continue
    except Exception:
        pass
    return result


def _fetch_multi_symbol_bars_live(
    symbols: List[str],
    n: int = 64,
) -> tuple:
    """Fetch M1 bars + compute per-symbol staleness.

    Returns:
        (bars_dict, stale_flags, max_staleness_s)
        stale_flags: Dict[symbol, bool] — True if latest bar > _STALE_THRESHOLD_S old
        max_staleness_s: float — worst staleness across all fetched symbols
    """
    bars_dict: Dict[str, List[float]] = {}
    stale_flags: Dict[str, bool] = {}
    max_stale = 0.0
    now_s = time.time()
    try:
        import MetaTrader5 as _mt5
        for sym in symbols:
            try:
                rates = _mt5.copy_rates_from_pos(sym, _mt5.TIMEFRAME_M1, 0, n)
                if rates is None or len(rates) < 30:
                    stale_flags[sym] = True
                    continue
                last_bar_time = float(rates[-1]["time"])   # epoch seconds
                age_s = now_s - last_bar_time
                stale_flags[sym] = age_s > _STALE_THRESHOLD_S
                if age_s > max_stale:
                    max_stale = age_s
                bars_dict[sym] = [float(r["close"]) for r in rates]
            except Exception:
                stale_flags[sym] = True
                continue
    except Exception:
        pass
    return bars_dict, stale_flags, round(max_stale, 2)


def _compute_pearson(bars_dict: Dict[str, List[float]]) -> List[List[float]]:
    """Compute NxN Pearson correlation matrix from close-price series.

    Pure Python / math — no pandas, no numpy dependency.
    Aligns all series to the minimum available length.
    Diagonal is forced to 1.0; matrix is enforced symmetric.
    Values are rounded to 4 decimal places.

    Args:
        bars_dict: Symbol -> list-of-floats close price mapping.

    Returns:
        NxN matrix (list-of-lists).  Returns [] if bars_dict is empty.
    """
    symbols = list(bars_dict.keys())
    n = len(symbols)
    if n == 0:
        return []

    min_len = min(len(v) for v in bars_dict.values())
    if min_len < 2:
        return [[1.0] * n for _ in range(n)]

    series = {s: bars_dict[s][-min_len:] for s in symbols}

    matrix: List[List[float]] = []
    for i, si in enumerate(symbols):
        row: List[float] = []
        xi = series[si]
        mu_i = sum(xi) / min_len
        for j, sj in enumerate(symbols):
            if i == j:
                row.append(1.0)
                continue
            xj = series[sj]
            mu_j = sum(xj) / min_len
            num = sum((xi[k] - mu_i) * (xj[k] - mu_j) for k in range(min_len))
            std_i = math.sqrt(sum((xi[k] - mu_i) ** 2 for k in range(min_len)))
            std_j = math.sqrt(sum((xj[k] - mu_j) ** 2 for k in range(min_len)))
            if std_i == 0.0 or std_j == 0.0:
                row.append(0.0)
            else:
                r = num / (std_i * std_j)
                r = max(-1.0, min(1.0, r))
                row.append(round(r, 4))
        matrix.append(row)

    # Enforce symmetry (average upper and lower triangles)
    for i in range(n):
        for j in range(i + 1, n):
            avg = round((matrix[i][j] + matrix[j][i]) / 2, 4)
            matrix[i][j] = avg
            matrix[j][i] = avg

    return matrix


def _detect_regime(
    matrix: List[List[float]],
    symbols: List[str],
) -> str:
    """Classify market regime from average absolute off-diagonal correlation.

    Thresholds:
        CRISIS       avg >= 0.80
        TRENDING     avg >= 0.50
        NORMAL       avg >= 0.30
        DECORRELATED avg <  0.30
        UNKNOWN      empty input

    Args:
        matrix:  NxN correlation matrix (list-of-lists).
        symbols: Symbol list (used only for length validation).

    Returns:
        Regime tag string.
    """
    if not matrix or not symbols:
        return "UNKNOWN"
    n = len(matrix)
    if n < 2:
        return "UNKNOWN"

    off_diag: List[float] = []
    for i in range(n):
        for j in range(n):
            if i != j:
                try:
                    off_diag.append(abs(float(matrix[i][j])))
                except Exception:
                    pass

    if not off_diag:
        return "UNKNOWN"

    avg = sum(off_diag) / len(off_diag)
    if avg >= 0.80:
        return "CRISIS"
    elif avg >= 0.50:
        return "TRENDING"
    elif avg >= 0.30:
        return "NORMAL"
    else:
        return "DECORRELATED"


def _synthetic_correlation(symbols: List[str]) -> List[List[float]]:
    """Generate a realistic synthetic NxN correlation matrix (SHADOW mode fallback).

    Intra-class correlations are higher than cross-class correlations:
        FX      - FX:      0.75
        METAL   - METAL:   0.70
        CRYPTO  - CRYPTO:  0.80
        INDEX   - INDEX:   0.85
        ENERGY  - ENERGY:  0.75
        cross-class:       0.20

    Diagonal = 1.0.  Matrix is symmetric by construction.

    Args:
        symbols: List of symbol names.

    Returns:
        NxN correlation matrix.
    """
    _ASSET_CLASS: Dict[str, str] = {
        "EURUSD": "FX",     "GBPUSD": "FX",     "USDJPY": "FX",
        "AUDUSD": "FX",     "USDCHF": "FX",     "USDCAD": "FX",
        "NZDUSD": "FX",
        "XAUUSD": "METAL",  "XAGUSD": "METAL",
        "BTCUSD": "CRYPTO", "ETHUSD": "CRYPTO",
        "US30":   "INDEX",  "US500":  "INDEX",
        "USOIL":  "ENERGY", "UKOIL":  "ENERGY",
    }
    _INTRA: Dict[str, float] = {
        "FX": 0.75, "METAL": 0.70, "CRYPTO": 0.80,
        "INDEX": 0.85, "ENERGY": 0.75,
    }
    _INTER = 0.20

    n = len(symbols)
    matrix: List[List[float]] = []
    for i in range(n):
        row: List[float] = []
        ci = _ASSET_CLASS.get(symbols[i], "OTHER")
        for j in range(n):
            if i == j:
                row.append(1.0)
            elif j < i:
                # Copy from already-computed symmetric counterpart
                row.append(matrix[j][i])
            else:
                cj = _ASSET_CLASS.get(symbols[j], "OTHER")
                if ci == cj:
                    row.append(_INTRA.get(ci, 0.50))
                else:
                    row.append(_INTER)
        matrix.append(row)
    return matrix


# ---------------------------------------------------------------------------
# Correlation matrix export (fail-soft, non-blocking)
# ---------------------------------------------------------------------------

def _export_correlation_matrix(
    artifact: Dict[str, Any],
    omni_ctx: Optional[Dict[str, Any]] = None,
    output_path: Optional[Path] = None,
) -> None:
    """Export correlation matrix to JSON after each compute tick.

    Two modes:
      - omni_ctx provided  → 11-field multi-symbol format.
      - omni_ctx=None      → legacy 4-field format read from
                             artifact.brain_context.omnigraph (backward-compat).

    Fail-soft: any error is logged to stderr; function returns silently.
    Uses atomic write (write to .tmp then os.replace) to prevent partial reads.

    Args:
        artifact:    Full run_compute return dict.
        omni_ctx:    Multi-symbol correlation context dict (optional).
        output_path: Override destination path (default: _CORR_MATRIX_PATH).
    """
    path = Path(output_path) if output_path is not None else _CORR_MATRIX_PATH
    try:
        if omni_ctx is not None:
            # ── New 11-field multi-symbol format ──────────────────────────
            symbols = omni_ctx.get("symbols")
            matrix  = omni_ctx.get("matrix")
            if not isinstance(symbols, list) or not isinstance(matrix, list) or not matrix:
                print(
                    "[compute_runner] WARNING: _export_correlation_matrix:"
                    " omni_ctx symbols/matrix invalid — skip",
                    file=sys.stderr,
                )
                return
            payload: Dict[str, Any] = {
                "timestamp_utc":      datetime.now(timezone.utc).isoformat(),
                "symbols":            symbols,
                "matrix":             matrix,
                "source":             omni_ctx.get("source", "multi_symbol_correlation"),
                "correlation_method": omni_ctx.get("correlation_method", "pearson"),
                "rolling_window":     omni_ctx.get("rolling_window", 64),
                "n_symbols":          omni_ctx.get("n_symbols", len(symbols)),
                "n_bars":             omni_ctx.get("n_bars", 0),
                "regime_tag":         omni_ctx.get("regime_tag", "UNKNOWN"),
                "mode":               omni_ctx.get("mode", "SHADOW"),
                "staleness_s":        omni_ctx.get("staleness_s", 0.0),
            }

        else:
            # ── Legacy 4-field format (backward-compat) ───────────────────
            brain_context = artifact.get("brain_context")
            if not isinstance(brain_context, dict):
                print(
                    "[compute_runner] WARNING: _export_correlation_matrix:"
                    " brain_context missing or not dict — skip",
                    file=sys.stderr,
                )
                return

            omnigraph = brain_context.get("omnigraph")
            if not isinstance(omnigraph, dict):
                print(
                    "[compute_runner] WARNING: _export_correlation_matrix:"
                    " brain_context.omnigraph missing or not dict — skip",
                    file=sys.stderr,
                )
                return

            symbols = omnigraph.get("symbols")
            matrix  = omnigraph.get("correlation_matrix")

            if not isinstance(symbols, list) or not isinstance(matrix, list) or not matrix:
                print(
                    "[compute_runner] WARNING: _export_correlation_matrix:"
                    f" symbols={type(symbols).__name__} matrix={type(matrix).__name__}"
                    " empty or wrong type — skip",
                    file=sys.stderr,
                )
                return

            payload = {
                "timestamp_utc": datetime.now(timezone.utc).isoformat(),
                "symbols":       symbols,
                "matrix":        matrix,
                "source":        "omnigraph_hybrid_v2",
            }

        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = Path(str(path) + ".tmp")
        tmp.write_text(json.dumps(payload, ensure_ascii=True), encoding="utf-8")
        os.replace(str(tmp), str(path))

    except Exception as exc:
        print(
            f"[compute_runner] WARNING: _export_correlation_matrix failed: {exc}",
            file=sys.stderr,
        )


# ---------------------------------------------------------------------------
# EA3 support: brain_router wrapper + compare-log writer
# ---------------------------------------------------------------------------

def _run_brain_router(context: Dict[str, Any]) -> Dict[str, Any]:
    """Fail-soft brain_router wrapper.

    Returns routing decision with action=EXECUTE|BLOCK, caution_level=NONE|LOW|HIGH.
    Falls back to BLOCK on any import or runtime error (fail-closed).

    Args:
        context: Signal context dict (trinity_m1, eql, gim, vapd, omnigraph, budget, ...).

    Returns:
        Dict with at least: action, caution_level, reason_codes.
    """
    try:
        import brain_router as _br
        return _br.run(context)
    except Exception as exc:
        return {
            "action":        "BLOCK",
            "caution_level": "NONE",
            "reason_codes":  ["RC_ROUTER_FALLBACK"],
            "error":         str(exc),
        }


def _append_ea3_compare_log(
    entry: Dict[str, Any],
    path: Optional[Path] = None,
) -> None:
    """Append one EA3 compare entry to JSONL log every live tick.

    Format (13 fields — matches ea3_compare_log schema):
        timestamp, symbol, router_action, ea3_action, delta,
        confidence, latency_ms, reason_codes, anomaly_score,
        router_caution_level, ea3_veto_applied, ea3_lot_modifier,
        router_override_count

    Fail-soft: any error is logged to stderr; function never raises.
    Append mode: does NOT truncate; safe for concurrent readers.

    Args:
        entry: Dict with all 13 schema fields.
        path:  Override destination path (default: _EA3_COMPARE_LOG_PATH).
    """
    _path = path if path is not None else _EA3_COMPARE_LOG_PATH
    try:
        _path.parent.mkdir(parents=True, exist_ok=True)
        with open(_path, "a", encoding="utf-8") as _fh:
            _fh.write(json.dumps(entry, ensure_ascii=True) + "\n")
    except Exception as exc:
        print(
            f"[compute_runner] WARNING: _append_ea3_compare_log failed: {exc}",
            file=sys.stderr,
        )


# ---------------------------------------------------------------------------
# Fail-soft wrappers for Lane-1 modules
# ---------------------------------------------------------------------------

def _run_gim(timeout: float = 2.0) -> Dict[str, Any]:
    """Fail-soft GIM wrapper with 2s timeout.

    GIM calls mt5.initialize() for 4 symbols in parallel threads.
    When MT5 is not running, each initialize() blocks ~10s before returning False.
    Timeout wrapper caps total GIM latency at 2s -> returns FAILED fail-soft.
    """
    import concurrent.futures as _cf
    _fail: Dict[str, Any] = {
        "composite_score": 0.0,
        "is_risk_elevated": False,
        "fetch_status": "FAILED",
        "error": "",
    }
    try:
        import gim as _gim_mod
        _pool = _cf.ThreadPoolExecutor(max_workers=1, thread_name_prefix="gim_bg")
        try:
            return _pool.submit(_gim_mod.run).result(timeout=timeout)
        except _cf.TimeoutError:
            _fail["error"] = f"GIM_TIMEOUT_{timeout}s"
            return _fail
        except Exception as exc:
            _fail["error"] = str(exc)
            return _fail
        finally:
            _pool.shutdown(wait=False)
    except Exception as exc:
        _fail["error"] = str(exc)
        return _fail


def _run_eql(broker_audit: Dict[str, Any], execution_data: Dict[str, Any],
             config: Dict[str, Any]) -> Dict[str, Any]:
    try:
        import eql
        return eql.run(broker_audit, execution_data, config)
    except Exception as e:
        return {"eql_output": {"broker_trust": 0.0, "anomalies": [],
                "metadata": {"reason_codes": [], "error": str(e)}}}


def _run_vapd(market_window: List[Dict[str, Any]], config: Dict[str, Any]) -> Dict[str, Any]:
    try:
        import vapd
        closes = [float(b.get("c", b.get("close", 0.0)))
                  for b in market_window if isinstance(b, dict)]
        if len(closes) < 5:
            return {"signal": {"signal_type": "NONE", "confidence": 0.0},
                    "error": "insufficient_data"}
        return vapd.run(closes, config)
    except Exception as e:
        return {"signal": {"signal_type": "NONE", "confidence": 0.0}, "error": str(e)}


def _run_omnigraph(context: Dict[str, Any]) -> Dict[str, Any]:
    try:
        import omnigraph_hybrid_v2
        return omnigraph_hybrid_v2.run(context)
    except Exception as e:
        return {"omnigraph_advisory": {"veto_signal": False, "falsifier_verdict": "PASS",
                "reason_codes": ["RC_OMNIGRAPH_EVIDENCE_INCOMPLETE"], "error": str(e)}}


def _run_ws1(pulse_input: dict) -> dict:
    """
    Fail-soft WS1 telemetry wrapper.
    Guard Rail G1: read-only -- no veto, no policy override, no Lane-2 influence.
    Guard Rail G2: inputs must be pre-captured at ingestion boundary (not here).
    Guard Rail G3: always returns dict -- never raises -- never breaks Lane-2.
    """
    broker_ts_ns    = pulse_input.get("broker_ts_ns")
    local_arrive_ns = pulse_input.get("local_arrive_ns")
    local_utc_ns    = pulse_input.get("local_utc_ns")

    # Fail-soft: missing inputs -> SKIP
    if not all([broker_ts_ns, local_arrive_ns, local_utc_ns]):
        return {"status": "SKIP", "reason_codes": ["RC_CR_PULSE_SKIPPED"]}

    try:
        from ws1_the_pulse.engine import update_and_measure
        cfg = pulse_input.get("ws1_config", {
            "capacity":            256,
            "window_n":            32,
            "min_samples":         8,
            "jitter_p95_ms":       200.0,
            "spike_interval_ms":   2000.0,
            "high_latency_p95_ms": 100.0,
            "skew_abs_ms":         5.0,
        })
        tick_event = {
            "broker_ts_ns":    int(broker_ts_ns),
            "local_arrive_ns": int(local_arrive_ns),
            "local_utc_ns":    int(local_utc_ns),
        }
        # Gemini engine returns {"pulse_context": {...}}
        result = update_and_measure(tick_event, cfg)
        return {
            "status":        "OK",
            "pulse_context": result.get("pulse_context", {}),
            "reason_codes":  ["RC_CR_PULSE_OK"],
        }
    except Exception as e:
        return {"status": "SKIP", "reason_codes": ["RC_CR_PULSE_SKIPPED"], "error": str(e)}


# ---------------------------------------------------------------------------
# Allowlist
# ---------------------------------------------------------------------------

ALLOWLIST = {
    "RC_CR_SUCCESS",
    "RC_CR_COLLECT_OK",
    "RC_CR_COLLECT_FAIL",
    "RC_CR_M1_OK",
    "RC_CR_M1_FAIL",
    "RC_CR_ADAPTER_BARS_CONVERTED",
    "RC_CR_ADAPTER_SIGNATURE_MAPPED",
    "RC_CR_ERROR",
    "RC_CR_PULSE_OK",
    "RC_CR_PULSE_SKIPPED",
    "RC_CR_EA3_OK",
    "RC_CR_EA3_SKIPPED",
    "RC_CR_OMNI_INSUFFICIENT_BARS",
    "RC_CR_OMNI_INPUT_MISSING",
}


def run_compute(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Compute lane entry point.

    Returns artifact matching GOLDEN_IO_LOCK_COMPUTE_RUNNER.yaml.
    """
    reason_codes: List[str] = []
    errors: List[Dict[str, str]] = []

    def add_rc(rc: str) -> None:
        if rc not in ALLOWLIST:
            errors.append({"code": "RC_NOT_ALLOWLISTED", "message": rc})
            raise RuntimeError("reason code not allowlisted")
        reason_codes.append(rc)

    # Input normalization
    symbol = str(payload.get("symbol", ""))
    timeframe = str(payload.get("timeframe", ""))
    end_time_utc = str(payload.get("end_time_utc", ""))
    window_bars = int(payload.get("window_bars", 0))
    budget = float(payload.get("budget", 0.0)) if payload.get("budget") is not None else 0.0

    raw_market = payload.get("market_bars", [])
    raw_truth = payload.get("truth_bars", None)

    input_block: Dict[str, Any] = {
        "symbol": symbol,
        "timeframe": timeframe,
        "end_time_utc": end_time_utc,
        "window_bars": window_bars,
        "market_bars_count": len(raw_market) if isinstance(raw_market, list) else 0,
    }
    if isinstance(raw_truth, list):
        input_block["truth_bars_count"] = len(raw_truth)
    if "budget" in payload:
        input_block["budget"] = budget
    if "vip_config" in payload:
        input_block["vip_config_digest"] = canonical_digest(payload.get("vip_config"))

    generated_at_utc = end_time_utc or "1970-01-01T00:00:00Z"
    canonical_input_digest = canonical_digest({"payload": payload})

    # Defaults
    collect_result: Dict[str, Any] = {"ok": False, "market_window": [], "collector_meta": {}}
    m1_out: Dict[str, Any] = {"trust_score": 0.0, "noise_residual": {}, "broker_audit": {}}
    brain_context: Dict[str, Any] = {"pipeline_status": {"status": "ERROR"},
                                     "trinity_m1": {}, "budget": budget,
                                     "pulse_context": {"status": "SKIP", "reason_codes": ["RC_CR_PULSE_SKIPPED"]}}

    try:
        if not isinstance(raw_market, list):
            raise ValueError("market_bars must be a list")
        market_bars = build_bars(raw_market)
        truth_bars = build_bars(raw_truth) if isinstance(raw_truth, list) else None
        add_rc("RC_CR_ADAPTER_BARS_CONVERTED")

        collect_result, sig_rc = call_collect_window(
            symbol=symbol,
            timeframe=timeframe,
            end_time_utc=end_time_utc,
            window_bars=window_bars,
            market_bars=market_bars,
            truth_bars=truth_bars,
        )
        add_rc(sig_rc)
        add_rc("RC_CR_COLLECT_OK" if bool(collect_result.get("ok", True)) else "RC_CR_COLLECT_FAIL")

        # Trinity M1
        m1_out = call_trinity_m1(
            symbol=symbol,
            timeframe=timeframe,
            market_window=collect_result.get("market_window"),
            truth_window=collect_result.get("truth_window"),
        )
        add_rc("RC_CR_M1_OK")

        # ---------------------------------------------------------------------------
        # Lane-1 Wiring: GIM -> EQL -> VAPD -> OmniGraph
        # ---------------------------------------------------------------------------
        gim_out = _run_gim()

        execution_data = {
            "slippage_pips": m1_out.get("broker_audit", {}).get("slippage", 0.0),
            "spread_pips": m1_out.get("broker_audit", {}).get("spread_entry", 0.0),
            "reject_rate": 0.0,
        }
        eql_out = _run_eql(
            broker_audit=m1_out.get("broker_audit", {"trust_score": 0.0}),
            execution_data=execution_data,
            config=payload.get("vip_config", {}),
        )

        vapd_out = _run_vapd(
            market_window=collect_result.get("market_window", []),
            config=payload.get("vip_config", {}),
        )

        # -- OmniGraph v2 -- price_matrix build + fail-closed pre-validation ------
        _market_window = collect_result.get("market_window", [])
        _eurusd_closes = [
            float(b.get("c", b.get("close", 0.0)))
            for b in _market_window if isinstance(b, dict)
        ]
        _gbp_bars_raw  = payload.get("gbp_bars", [])
        _gbpusd_closes = [
            float(b.get("c", b.get("close", 0.0)))
            for b in _gbp_bars_raw if isinstance(b, dict)
        ]
        _OMNI_MIN_BARS = 20
        _omni_skip: Dict[str, Any] = {
            "veto_signal": False, "match_score": 0.0, "anomaly_score": 0.0,
            "correlation_matrix": [], "scenario_id": "SC_NORMAL", "reason_codes": [],
        }
        if not _gbpusd_closes:
            add_rc("RC_CR_OMNI_INPUT_MISSING")
            omni_out = {**_omni_skip, "reason_codes": ["RC_CR_OMNI_INPUT_MISSING"]}
        elif len(_eurusd_closes) < _OMNI_MIN_BARS or len(_gbpusd_closes) < _OMNI_MIN_BARS:
            add_rc("RC_CR_OMNI_INSUFFICIENT_BARS")
            omni_out = {**_omni_skip, "reason_codes": ["RC_CR_OMNI_INSUFFICIENT_BARS"]}
        else:
            _min_len = min(len(_eurusd_closes), len(_gbpusd_closes))
            omni_context: Dict[str, Any] = {
                "price_matrix": [
                    _eurusd_closes[-_min_len:],
                    _gbpusd_closes[-_min_len:],
                ],
                "config": {
                    "correlation_window": 20,
                    "veto_threshold":     0.8,
                },
                "timestamp_utc": end_time_utc or "1970-01-01T00:00:00Z",
                "symbols":       _CORR_SYMBOLS,
            }
            omni_out = _run_omnigraph(omni_context)

        # ── Derive anomaly_score (omnigraph primary, vapd fallback) ──────────
        _anomaly_score: float = float(omni_out.get("anomaly_score", 0.0))
        if _anomaly_score == 0.0:
            _vs = vapd_out if isinstance(vapd_out, dict) else {}
            _anomaly_score = float(
                _vs.get("anomaly_score",
                    (_vs.get("signal") or {}).get("anomaly_score", 0.0)
                )
            )

        # ── Derive confidence from EQL broker_trust -> HIGH|MEDIUM|LOW ───────
        _broker_trust: float = float(
            (eql_out.get("eql_output") or {}).get("broker_trust", 0.0)
        )
        if _broker_trust >= 0.8:
            _confidence = "HIGH"
        elif _broker_trust >= 0.5:
            _confidence = "MEDIUM"
        else:
            _confidence = "LOW"

        # ── brain_router: EXECUTE|BLOCK + caution_level ───────────────────────
        # Use the canonical schema matching live_runner_continuous so ea3_compare_log
        # reflects the same router path as live execution.
        _corr_break: bool = bool(gim_out.get("corr_break", False))
        _omni_adv = omni_out.get("omnigraph_advisory", omni_out)
        _router_input: Dict[str, Any] = {
            "evidence_complete": m1_out.get("trust_score", 0.0) >= 0.5,
            "veto_signal":       _omni_adv.get("veto_signal",   False),
            "match_score":       _omni_adv.get("match_score",   0.0),
            "anomaly_score":     _anomaly_score,
            "stability_score":   m1_out.get("trust_score", 0.0),
            "context_hash_seed": "",
            "side_hint":         str((vapd_out if isinstance(vapd_out, dict) else {}).get("signal_type", "NONE")),
        }
        _router_out           = _run_brain_router(_router_input)
        _router_action        = str(_router_out.get("action", "BLOCK"))
        _router_caution_level = str(_router_out.get("caution_level", "NONE"))

        # ── EA3 -- full-context wiring ────────────────────────────────────────
        _vapd_dict = vapd_out if isinstance(vapd_out, dict) else {}
        _eql_output = eql_out.get("eql_output") or {}
        ea3_base: Dict[str, Any] = {
            # Legacy fields (kept for backward compat)
            "trinity_m1":    m1_out,
            "eql":           _eql_output,
            "gim": {"regime": {
                "state":      gim_out.get("fetch_status", "UNKNOWN"),
                "corr_break": _corr_break,
            }},
            "vapd": {"signal": vapd_out},
            "scenario_registry": payload.get("scenario_registry", {
                "version": "1.1", "scenarios": []
            }),
            "anomaly_score":         _anomaly_score,
            "confidence":            _confidence,   # keep string for compare-log
            "router_action":         _router_action,
            "router_caution_level":  _router_caution_level,
            "router_override_count": _router_state["override_count"],
            # ── EA3 _REQUIRED_MARKET ─────────────────────────────────────────
            "symbol":             symbol,
            "timeframe":          timeframe,
            "timestamp_utc":      end_time_utc or datetime.now(timezone.utc).isoformat(),
            "price_context":      float(collect_result.get("market_window", [{}])[-1].get("c", 0.0)) if collect_result.get("market_window") else 0.0,
            "spread_context":     float(_eql_output.get("spread", 0.0)),
            "volatility_context": float(_vapd_dict.get("volatility_current", 0.0)),
            "momentum_context":   str(_vapd_dict.get("signal_type", "NONE")),
            # ── EA3 _REQUIRED_ADVISORY ───────────────────────────────────────
            "scenario_tag":         str(omni_out.get("scenario_id", "SC_NORMAL")),
            "stability_score":      float(m1_out.get("trust_score", 0.0)),
            "confidence_score":     _broker_trust,   # numeric float — EA3 contract
            "veto_hint":            bool(_omni_adv.get("veto_signal", False)),
            "conflict_flag":        _corr_break,
            "evidence_complete":    m1_out.get("trust_score", 0.0) >= 0.5,
            "node_consensus_state": True,
            # ── EA3 _REQUIRED_SAFETY ─────────────────────────────────────────
            "session_state":        str(payload.get("mode", "SHADOW")),
            "market_open_state":    True,
            "tradable_state":       True,
            "kill_switch_state":    False,
            "guard_precheck_state": True,
            "allowed_mode":         str(payload.get("mode", "SHADOW")),
        }
        _ea3_enabled = bool(payload.get("ea3_enabled", False))
        _t_ea3 = time.perf_counter()
        try:
            import ea3 as _ea3_mod
            ea3_context: Dict[str, Any] = {
                **ea3_base,
                "omnigraph_output": omni_out,
                "ea3_enabled":      _ea3_enabled,
            }
            ea3_out = _ea3_mod.run(ea3_context)
        except Exception:
            ea3_out = {}
        _ea3_latency_ms: float = (time.perf_counter() - _t_ea3) * 1000.0
        add_rc("RC_CR_EA3_OK" if _ea3_enabled else "RC_CR_EA3_SKIPPED")

        # ── Post-EA3: extract action, update override counter, write log ──────
        _ea3_action       = str(ea3_out.get("action", "ALLOW")) if isinstance(ea3_out, dict) else "ALLOW"
        _ea3_veto_applied = _ea3_action == "VETO"
        _ea3_lot_modifier = float(ea3_out.get("lot_modifier", 1.0)) if isinstance(ea3_out, dict) else 1.0
        _ea3_reason_codes = list(ea3_out.get("reason_codes", [])) if isinstance(ea3_out, dict) else []

        # Increment override counter when router said EXECUTE but EA3 overrode
        if _router_action == "EXECUTE" and _ea3_action in ("HOLD", "VETO"):
            _router_state["override_count"] += 1

        # Append ea3_compare_log (fail-soft — never raises, never blocks Lane-2)
        _ea3_mode = "ACTIVE" if _ea3_veto_applied else ("LIMITED" if _ea3_action == "VETO" else "COMPARE")
        _append_ea3_compare_log({
            "timestamp_utc":         datetime.now(timezone.utc).isoformat(),
            "symbol":                symbol,
            "router_action":         _router_action,
            "ea3_action":            _ea3_action,
            "delta":                 _router_action != _ea3_action,
            "mode":                  _ea3_mode,
            "confidence":            _confidence,
            "latency_ms":            round(_ea3_latency_ms, 3),
            "reason_codes":          _ea3_reason_codes,
            "anomaly_score":         round(_anomaly_score, 6),
            "router_caution_level":  _router_caution_level,
            "ea3_veto_applied":      _ea3_veto_applied,
            "ea3_lot_modifier":      _ea3_lot_modifier,
            "router_override_count": _router_state["override_count"],
        })

        # WS1 -- read-only telemetry, fail-soft, never blocks Lane-2
        ws1_out = _run_ws1(payload.get("pulse_input", {}))
        for _rc in ws1_out.get("reason_codes", []):
            if _rc in ALLOWLIST:
                reason_codes.append(_rc)

        brain_context = {
            "pipeline_status": {"status": "OK"},
            "trinity_m1": m1_out,
            "eql": eql_out,
            "gim": gim_out,
            "vapd": vapd_out,
            "omnigraph": omni_out,
            "ea3": ea3_out,
            "pulse_context": ws1_out,
            "budget": budget,
        }

        add_rc("RC_CR_SUCCESS")
        status = "success"

    except Exception as e:
        status = "error"
        add_rc("RC_CR_ERROR")
        errors.append({"code": type(e).__name__, "message": str(e)})

    artifact: Dict[str, Any] = {
        "status": status,
        "generated_at_utc": generated_at_utc,
        "input": input_block,
        "collect_result": collect_result,
        "trinity_m1": m1_out,
        "brain_context": brain_context,
        "reason_codes": reason_codes,
        "determinism": {
            "canonical_input_digest": canonical_input_digest,
            "canonical_output_digest": canonical_digest({
                "status": status,
                "generated_at_utc": generated_at_utc,
                "input": input_block,
                "collect_result": collect_result,
                "trinity_m1": m1_out,
                "brain_context": brain_context,
                "reason_codes": reason_codes,
                "errors": errors,
            }),
        },
        "errors": errors,
    }

    # ---------------------------------------------------------------------------
    # Multi-symbol correlation matrix export
    # (fail-soft — never raises, never blocks Lane-2)
    # ---------------------------------------------------------------------------
    try:
        _vip_mode = str((payload.get("vip_config") or {}).get("mode", "SHADOW"))
        if _vip_mode in ("LIVE", "REAL"):
            _ms_bars, _stale_flags, _staleness_s = _fetch_multi_symbol_bars_live(_CORR_SYMBOLS)
            _n_stale   = sum(1 for v in _stale_flags.values() if v)
            _n_total   = len(_CORR_SYMBOLS)
            _degraded  = (_n_stale / _n_total) > _DEGRADED_RATIO if _n_total else True
            if _degraded or len(_ms_bars) < 2:
                _ms_matrix = _synthetic_correlation(_CORR_SYMBOLS)
                _ms_method = "synthetic"
                _ms_n_bars = 0
                _ms_regime = "UNKNOWN"
                _ms_mode   = "DEGRADED"
            else:
                _fresh_syms = [s for s in _CORR_SYMBOLS if s in _ms_bars and not _stale_flags.get(s, True)]
                _fresh_bars = {s: _ms_bars[s] for s in _fresh_syms}
                _ms_matrix  = _compute_pearson(_fresh_bars)
                _ms_method  = "pearson"
                _ms_n_bars  = min(len(v) for v in _fresh_bars.values()) if _fresh_bars else 0
                _ms_regime  = _detect_regime(_ms_matrix, _fresh_syms)
                _ms_mode    = _vip_mode
        else:
            _ms_bars, _stale_flags, _staleness_s = {}, {}, 0.0
            _ms_matrix = _synthetic_correlation(_CORR_SYMBOLS)
            _ms_method = "synthetic"
            _ms_n_bars = 0
            _ms_regime = _detect_regime(_ms_matrix, _CORR_SYMBOLS)
            _ms_mode   = "SHADOW"

        _ms_ctx: Dict[str, Any] = {
            "symbols":            _CORR_SYMBOLS,
            "matrix":             _ms_matrix,
            "source":             "multi_symbol_correlation",
            "correlation_method": _ms_method,
            "rolling_window":     64,
            "n_symbols":          len(_CORR_SYMBOLS),
            "n_bars":             _ms_n_bars,
            "regime_tag":         _ms_regime,
            "mode":               _ms_mode,
            "staleness_s":        _staleness_s,
            "stale_count":        sum(1 for v in _stale_flags.values() if v),
        }
        _export_correlation_matrix(artifact, _ms_ctx)
    except Exception as _ms_exc:
        print(
            f"[compute_runner] WARNING: multi-symbol correlation block failed: {_ms_exc}",
            file=sys.stderr,
        )
        _export_correlation_matrix(artifact)

    return artifact
